
// از این آرایه استفاده نمیشه و مستقیم از سرور گرفته میشه
const CarTypeArray= [
    {
      "value": "1",
      "label": "وانت بار"
    },
    {
      "value": "2",
      "label": "مزدا"
    },
    {
      "value": "3",
      "label": "نیسان"
    },
    {
      "value": "4",
      "label": "خاور روباز"
    },
    {
      "value": "5",
      "label": "خاور مسقف"
    },
    {
      "value": "6",
      "label": "تک"
    },
    {
      "value": "7",
      "label": "ده چرخ"
    },
    {
      "value": "8",
      "label": "تریلی کفی"
    },
    {
      "value": "9",
      "label": "تریلی لبه دار"
    },
    {
      "value": "10",
      "label": "تریلی چادری"
    }
  ];

export default CarTypeArray;