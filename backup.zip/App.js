import 'react-native-gesture-handler';
import React from 'react'
import { View, Text } from 'react-native';
import { createStackNavigator } from '@react-navigation/stack';
import TestScreen from './Screens/Test/TestScreen';
import HomeScreen from './Screens/Home/HomeScreen';
// =================================================================
 
const Stack = createStackNavigator();

// =================================================================
export default function App() {
 
  // =================================================================
  return (
    // <Stack.Navigator>
    //   <Stack.Screen name="TestScreen" component={TestScreen} />
    // </Stack.Navigator>
    <HomeScreen />
  )
}
