// =================================================================
export const persianStatus = (status) => {
    switch (status) {
        case ("NewCargo"): return "تایید نشده";
        case ("Active"): return "فعال";
        case ("TakeByDriver"): return "حمل شده";
        // case ("TakeByDriver"): return "در حال حمل";
        case ("CancelByDriver"): return "کنسل شده توسط راننده";
        case ("CancelBySubmitter"): return "کنسل شده توسط اعلام کننده";
        case ("UpdatedBySubmitter"): return "ویرایش شده";
        case ("UpdatedByAdmin"): return "ویرایش شده توسط مدیر";
        case ("DeleteByAdmin"): return "حذف شده توسط مدیر";
    }
}