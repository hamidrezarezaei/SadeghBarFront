import React, { useEffect, useState, useContext } from 'react'
import { Button,ScrollView, StyleSheet, Text, TouchableOpacity, View ,Alert} from 'react-native'
import { useToast } from "react-native-toast-notifications";
import { SmartGetById_Cargo_Api } from '../../Api/cargoApi';
import { Enter_Queue_Api, Exit_Queue_Api, ExtendTime_Queue_Api, GetItems_Queue_Api, TakeByDriver_Queue_Api } from '../../Api/queueApi';
import { CancelBySubmitter_Cargo_Api } from '../../Api/cargoApi';
import { globalStyles } from '../../assets/Styles/GlobalStyle';
import CargoInfo from '../../Component/CargoList/CargoInfo/CargoInfo';
import CargoSubmitterInfo from '../../Component/CargoList/CargoSubmitterInfo/CargoSubmitterInfo';
import Loading from '../../Component/Loading/Loading';
import Queue from '../../Component/CargoList/Queue/Queue';
import { cargoSingleStyles } from './CargoSingleStyle';
import CountDown from '../../Component/CargoList/CountDown/CountDown';
import UserContext from '../../Context/UserContext';

// =================================================================
export default function CargoSingleScreen({ navigation, route }) {
  const context = useContext(UserContext);

  const myUserId = context.CurrentUser?.id;
  const { id } = route.params;
  const [loading, setLoading] = useState(false);
  const [cargo, setCargo] = useState(null);
  const [queueItems, setQueueItems] = useState([]);
  const [currentQueueItem, setCurrentQueueItem] = useState(null);
  const [remainingTime, setRemainingTime] = useState(0);
  const [isMyCargo, setIsMyCargo] = useState(false);
  const toast = useToast();
  // =================================================================
  useEffect(() => {
    refreshScreen();
  }, []);
  // =================================================================
  useEffect(() => {
    const timerId = setInterval(() => {
      refreshScreen();
    }, 4000);
    return () => {
      clearInterval(timerId);
    };
  }, []);
  // =================================================================
  const refreshScreen = () => {
    try {
      // setLoading(true);

      loadCargo();
      loadQueueItems();

      // setLoading(false);
    }
    catch (error) {
      // setLoading(false);
      toast.show("خطا در ارتباط با سرور.", { type: "danger" });
    }
  }
  // =================================================================
  const loadCargo = async () => {
    try {
      let data = await SmartGetById_Cargo_Api(id);
      // console.log(id);
      if (data.messageStatus == "Successful") {
        //آیا بار ما همین یوزر است
        setIsMyCargo(data.messageData.data.submitterUserId == myUserId);
        setCargo(data.messageData.data);
      }
      else {
        toast.show(data.message, { type: "danger" });
      }
    }
    catch (error) {
      // setLoading(false);
      toast.show("خطا در ارتباط با سرور.", { type: "danger" });
    }
  }
  // =================================================================
  const loadQueueItems = async () => {
    let data = await GetItems_Queue_Api(id);
    if (data.messageStatus == "Successful") {
      setQueueItems(data.messageData.data);
      var t = data.messageData.data.filter(q => q.isMe && q.isFront)[0];

      //اگر کس دیگه ای بار را گرفته است برگرد
      if (isTakeByAnotherDriver(data.messageData.data)) {
        toast.show("بار توسط راننده دیگری گرفته شد.", { type: "warning" });
        navigation.goBack();
      }
      // console.log(t);
      setCurrentQueueItem(t);



      //اگر سر صف هستیم زمان باقی مانده را هم بگیر
      let x = data.messageData.data.filter(q => q.isMe && q.isFront);
      if (x && x.length)
        setRemainingTime(x[0].remainingSecond);
      else
        setRemainingTime(0);
    }
    else {
      // toast.show(data.message + 'krr', { type: "danger" });
    }
  }
  // =================================================================
  const enterToQueue = async () => {
    try {
      setLoading(true);
      let data = await Enter_Queue_Api(id);
      if (data.messageStatus == "Successful") {
        setLoading(false);
        refreshScreen();
        toast.show(data.message, { type: "success" });
      }
      else {
        setLoading(false);
        toast.show(data.message, { type: "danger" });
      }
    }
    catch (error) {
      setLoading(false);
      toast.show("خطا در ارتباط با سرور.", { type: "danger" });
    }
  }
  // =================================================================
  const exitFromQueueConfirm =  () => {
    Alert.alert('', 'آیا در مورد انصراف از این بار اطمینان دارید؟', [
      {
        text: 'خیر',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      { text: 'بله', onPress: () => exitFromQueue() },
    ]);
   
  }

  const exitFromQueue = async () => {
    try {
      setLoading(true);
      let data = await Exit_Queue_Api(id);
      if (data.messageStatus == "Successful") {
        setLoading(false);
        // refreshScreen();
        toast.show(data.message, { type: "success" });
        navigation.navigate('CargoListScreen');

      }
      else {
        setLoading(false);
        toast.show(data.message, { type: "danger" });
      }
    }
    catch (error) {
      setLoading(false);
      toast.show("خطا در ارتباط با سرور.", { type: "danger" });
    }
  }
  // =================================================================
  const takeByDriverConfirm = async () => {
    Alert.alert('', 'آیا در مورد گرفتن این بار اطمینان دارید؟', [
      {
        text: 'خیر',
        onPress: () => console.log('Cancel Pressed'),
        style: 'cancel',
      },
      { text: 'بله', onPress: () => takeByDriver() },
    ]);
   
  }
    const takeByDriver = async () => {
    try {
      setLoading(true);
      let data = await TakeByDriver_Queue_Api(id);
      if (data.messageStatus == "Successful") {
        setLoading(false);
        // refreshScreen();
        toast.show(data.message, { type: "success" });
        navigation.reset({
          index: 0,
          routes: [{ name: 'CargoListScreen' }],
        });
      }
      else {
        setLoading(false);
        toast.show(data.message, { type: "danger" });
      }
    }
    catch (error) {
      setLoading(false);
      toast.show("خطا در ارتباط با سرور.", { type: "danger" });
    }
  }
  // =================================================================
  const cancelBySubmitterConfirm = async () => {  Alert.alert('', 'آیا از کنسل شدن این بار اطمینان دارید؟', [
    {
      text: 'خیر',
      onPress: () => console.log('Cancel Pressed'),
      style: 'cancel',
    },
    { text: 'بله', onPress: () => cancelBySubmitter() },
  ]);
  }
    const cancelBySubmitter = async () => {
    try {
      setLoading(true);
      let data = await CancelBySubmitter_Cargo_Api(id);
      if (data.messageStatus == "Successful") {
        setLoading(false);
        // refreshScreen();
        toast.show(data.message, { type: "success" });
        navigation.navigate('CargoListScreen');
      }
      else {
        setLoading(false);
        toast.show(data.message, { type: "danger" });
      }
    }
    catch (error) {
      setLoading(false);
      toast.show("خطا در ارتباط با سرور.", { type: "danger" });
    }
  }
  // =================================================================
  const extendTime = async () => {
    try {
      setLoading(true);
      let data = await ExtendTime_Queue_Api(id);
      if (data.messageStatus == "Successful") {
        setRemainingTime(0);
        setLoading(false);
        refreshScreen();
        toast.show(data.message, { type: "success" });
      }
      else {
        setLoading(false);
        toast.show(data.message, { type: "danger" });
      }
    }
    catch (error) {
      setLoading(false);
      toast.show("خطا در ارتباط با سرور.", { type: "danger" });
    }
  }
  // =================================================================
  const isMeInFrontOfQueue = () => {
    let x = queueItems.filter(q => q.isMe && q.isFront);
    if (x && x.length)
      return true;
  }
  // =================================================================
  const isTakeByAnotherDriver = (qi) => {
    let x = qi.filter(q => q.status == 'Accepted' && !q.isMe);
    if (x && x.length)
      return true;
    return false;
  }
  // =================================================================

  return (
    <View style={{ flex: 1 }} nestedScrollEnabled={true} >

      <ScrollView style={cargoSingleStyles.screenContainer} keyboardShouldPersistTaps={'handled'}>
        <View style={[globalStyles.row]}>
          <Text style={[globalStyles.screen_Title]}>کد بار: {cargo?.code}</Text>
        </View>
        <CargoInfo
          cargo={cargo}
          isShowMoreInfoButton={false}
          isShowCompleteInfo={true}
          navigation={navigation}
        />

        {remainingTime > 0 ? (
          <CountDown
            remainingTime={remainingTime}
            onEnd={refreshScreen}
          />
        ) : (<></>)}

        < CargoSubmitterInfo
          cargo={cargo}
        />

        {/* اگر سر صف بودیم دیگه صف لازم نیست نمایش داده شود و اطلاعات تماس نمایش داده می شود */}
        {!isMeInFrontOfQueue() ? (
          <Queue
            queueItems={queueItems}
            onEnterToQueue={enterToQueue}
            onExitFromQueueConfirm={exitFromQueueConfirm}
            isMyCargo={isMyCargo}
            navigation={navigation}
          />
        ) :
          <View style={cargoSingleStyles.row_Buttons}>
            <TouchableOpacity
              style={[globalStyles.dangerButton, cargoSingleStyles.dontTakeButton]}
              onPress={exitFromQueueConfirm}>
              <Text style={[globalStyles.dangerButton_Text]}>این بار را نمی برم</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[globalStyles.successButton, cargoSingleStyles.takeButton]}
              onPress={takeByDriverConfirm}>
              <Text style={[globalStyles.successButton_Text]}>این بار را می برم</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[globalStyles.secondaryButton, cargoSingleStyles.cargoCanceledButton]}
              onPress={cancelBySubmitterConfirm}>
              <Text style={[globalStyles.secondaryButton_Text]}>اعلام کننده بار را لغو کرد</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style=
              {currentQueueItem && !currentQueueItem.isExtendTime
                ? [globalStyles.submitButton, cargoSingleStyles.extendTimeButton]
                : [globalStyles.submitButton, cargoSingleStyles.extendTimeButton, globalStyles.disabledButton]
              }
              onPress={extendTime}>
              <Text style={[globalStyles.submitButton_Text]}>نیاز به زمان بیشتر دارم</Text>
            </TouchableOpacity>
          </View>
        }
      </ScrollView>
      <Loading loading={loading} />

    </View>
  )
}